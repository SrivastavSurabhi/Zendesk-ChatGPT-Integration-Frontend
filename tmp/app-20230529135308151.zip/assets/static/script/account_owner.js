var client = ZAFClient.init();
let token=""
let current_user =""
let dev_subdomain =""

$(document).ready(function(){
    client.context().then(function (context) {
        dev_subdomain = context["account"]["subdomain"];
    });
    client.get('currentUser').then(
        function(data) {
            var user = data['currentUser'];
            current_user = data['currentUser'];
            if (user['role'] == 'admin'){
                $('.agent-area').addClass('d-none');     
                client.context().then(function (context) {
                    subdomain = context["account"]["subdomain"];
                    getToken().then(function(e){
                        configureAjax(subdomain);
                        BillingInfo(subdomain,user['role']);
                        initializeProjectDataTable(user['role'], subdomain);
                    }).catch(function(e){
                      console.log(error)
                    });
                    })                         
            }
            else{
                client.invoke('hide');
                $('.container-div').addClass('d-none');
                $('.payment_btn').addClass('d-none');
                $('.agent-area').removeClass('d-none');                           
            }
        }
        );
    client.on('pane.activated', function() {
        getWordWandAPIToken();
        configureAjax(subdomain);
    })
   
    $('#v-pills-tab a').click(function(){
        current_tab = $(this).attr('id')
        if (current_tab == 'v-pills-configure-tab'){
            client.context().then(function (context) {
                subdomain = context["account"]["subdomain"];
                configureAjax(subdomain);
                })      
        }
        else if (current_tab == 'v-pills-activity-tab'){  
            TaskTable.draw();
        }
        else if (current_tab == 'v-pills-admin-tab'){
            client.context().then(function (context) {
                subdomain = context["account"]["subdomain"];
                adminAjax(subdomain);
            });                              
        }
    });

    $('#submit_confg').click(function(){
        role = $('#role').val();
        sentiment = $('#sentiment').val();
        tone = $('#tone').val();
        client.context().then(function (context) {
            subdomain = context["account"]["subdomain"];
            submitConfiguration(role, sentiment ,tone,subdomain);
            })          
    })

    $('.manageapp').click(function(){
        $('#acessapp').modal().show();
        client.get('currentUser').then(
            function(data) {
                var user = data['currentUser'];
                $('.account-owner-mail').text(user['email']);
                fetchAllUsers(user)
        }
        );
    })

    $('#oauth').click(function(){
        client.get('currentUser').then(
            function(data) {
                var user_id = data['currentUser']['id'];
                window.open(urls.accountDash+"?id="+user_id+ "&token="+getWordWandAPIToken(), "_blank");
        }
        );
    })

    $('#payment_btn').click(function(){
        client.get('currentUser').then(
            function(data) {
                var user_id = data['currentUser']['id'];
                window.open(urls.accountDash+"?id="+user_id + "&token="+getWordWandAPIToken(),  "_blank");
            }
            ); 
    })

    $('#filter_submit').click(function(){
    from_date = $('#from_date').val();
    to_date = $('#to_date').val();
    TaskTable.draw()
    })

});

async function getToken(){
    let promise = new Promise(function (resolve, reject) {
    if(token == undefined || token == "")
    {
        getJWTtoken(current_user,dev_subdomain).then(function(e){
            token = e
            resolve(e)
        }).catch(function(e){
            getWordWandAPIToken()
        });
    }
    })
    return await promise;
}

function getWordWandAPIToken(){   
    if(token == undefined || token == "")
    {
        getJWTtoken(current_user,dev_subdomain).then(function(e){
            token = e
        }).catch(function(e){
            getWordWandAPIToken()
        });
    }
    return token;
}


async function getJWTtoken(user,subdomain){
    let promise = new Promise(function (resolve, reject) {
        $.ajax({
            url:  urls.getJWTtoken,
            data: { "name":user.name,  
                    "user_id":user.id,
                    "email":user.email,
                    "organization_id":subdomain,
                },
            beforeSend: function() { 
                console.log("before send")
            },
            complete: function() {
                console.log("complete")     
            },
            success:function(data) {  
                console.log("data",data)
                token = data['token']
                resolve(data['token']);
            },
            error: function(data) {
                reject(data)
            }
        })
    })
return await promise;
}

function activityAjax(user){
    url = urls.apiHitCount
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"GET",
        url:  url ,
        headers: {
            Authorization: "Bearer "+ getWordWandAPIToken(),
          },
        data: {"user_info":user},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")          
        },
        success:function(data) {  
            $('#activity_table tbody').empty()
            $.each(data, function(index, item){
                $('#activity_table tbody').append(`
                <tr>
                    <td>${item['date']}</td>
                    <td>${item['date']}</td>
                    <td>${item['hit_count']}</td>
                </tr>`)
            })
        },
        error: function() {
            console.log("error")
        }
    })
}

function configureAjax(subdomain){
    if (subdomain){
        url = urls.getConfigureData +subdomain
    }
    else{
        url = urls.getConfigureData
    }
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"GET",
        url:  url ,
        headers: {Authorization: "Bearer "+ getWordWandAPIToken()},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")  
        },
        success:function(data) {  
            result = JSON.parse(data)
            role = JSON.parse(result['role'])
            sentiment = JSON.parse(result['sentiment'])
            tone = JSON.parse(result['tone'])
            result1 = JSON.parse(result['selected_txt'])[0]
            $('#role').empty()
            $('#sentiment').empty()
            $('#tone').empty()
            $.each(role, function(index, item){
                $('#role').append(`<option value="${item.agentRoleAPI}">${item.agentRoleUI}</option>`);
            })
            $.each(sentiment, function(index, item){
                $('#sentiment').append(`<option value="${item.customerSentimentAPI}">${item.customerSentimentUI}</option>`);
            })
            $.each(tone, function(index, item){
                $('#tone').append(`<option value="${item.replyToneAPI}">${item.replyToneUI}</option>`);
            })
            try{
                $('#role').val(result1['role__agentRoleAPI'])
                $('#sentiment').val(result1['sentiment__customerSentimentAPI'])
                $('#tone').val(result1['tone__replyToneAPI'])
            }
            catch(e){
                console.log(e)
            }
        },
        error: function() {
            console.log("error")
        }
    })
}

function BillingInfo(subdomain, role){
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"GET",
        url:  urls.checkPricing +"?org_id="+subdomain +"&role="+role,
        headers: {Authorization: "Bearer "+ getWordWandAPIToken()},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")      
        },
        success:function(data) {  
            if (data['status']=='paid'){
                $('.container-div').removeClass('d-none');
                $('.payment_btn').addClass('d-none');
            }
            else if (data['status']=='unpaid'){
                $('.container-div').addClass('d-none');
                $('.payment_btn').removeClass('d-none');
            }
            
        },
        error: function() {
            console.log("error")
        }
    })
}


function adminAjax(subdomain){
    url = urls.getAdminData + subdomain
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"GET",
        url:  url ,
        headers: {Authorization: "Bearer "+ getWordWandAPIToken()},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")
        },
        success:function(data) {  
            console.log(data)
            if(data['subs'] == 'active'){
                $('.activebox').css('background','green').text(`Active`)
            }
            else if (data['subs'] == 'canceled'){
                $('.activebox').css('background','#baba18').text(`Canceled`)
            }
            else{
                $('.activebox').css('background','red').text(`Inactive`)
            }
        },
        error: function() {
            console.log("error")
        }
    })
}

function submitConfiguration(role, sentiment ,tone, organization_id){
    url = urls.saveDefaultConfig
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"POST",
        url:  url ,
        headers: {Authorization: "Bearer "+ getWordWandAPIToken()},
        data: {"role":role, "sentiment":sentiment, "tone":tone,"organization_id":organization_id},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")          
        },
        success:function(data) {  
            $('#alertPopup').modal().show()
        },
        error: function() {
            console.log("error")
        }
    })
}

function fetchAllUsers(user){
    url = urls.fetchAllUsers
    headers = {	"Content-Type": "application/json"}
    $.ajax({
        method:"GET",
        url:  url ,
        headers: {Authorization: "Bearer "+ getWordWandAPIToken()},
        data: {"user_info":user},
        beforeSend: function() { 
            console.log("Before send")
        },
        complete: function() {
            console.log("Complete")
        },
        success:function(data) {  
            $('.users_listing tbody').empty()
            $('.users-popup span').text(data.length)
            $.each(data, function(index,item){
                $('.users_listing tbody').append(
                `<tr>
                    <td><i class="fa fa-user"></i> ${item['name']}</td>
                    <td> ${item['email']}</td>
                    <td> ${item['role']}</td>
                    <td><button type="button" class="manageadmin">Add as app admin</button></td>
                </tr>`
                )
            })
        },
        error: function() {
            console.log("error")
        }
    })
}


function initializeProjectDataTable(role, organization_id)
{   
    var FinalTableOptions = {
        searching: true,
        processing: true,
        serverSide: true,
        stateSave: false,
        responsive: true,
        pagination:true,
        oLanguage: {
           sZeroRecords: "No data found",
           sProcessing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span>'
        },      
        columns: [
            {
                data: null,
                render: function(data, type, full, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }                   
            },
            {
                data: 'date',
                searchable: true,
            },
            {
                data: 'hit_count',
                searchable: true,
            },
       
        ],
        ajax: {
            "url":urls.apiHitCount+"?role="+role+"&&org="+organization_id,
            "data": function (d) {
                return $.extend( {},d, {
                    "search": {'value':$('#activity_table_filter input').val(),
                    'from_date':$('#from_date').val(),
                    'to_date': $('#to_date').val()
                }
                });
         }
        }
    }
    TaskTable = $('#activity_table').DataTable(FinalTableOptions);
}

